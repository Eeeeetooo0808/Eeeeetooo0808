module.exports = {
  token: process.env.token,
  globalBot: false, // false => if bot is private bot - true => if bot isn't private bot
  guildID: "941383131242561537",
}